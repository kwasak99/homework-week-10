package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var txtEmail: EditText;
    private lateinit var txtPassword: Edittext;
    private lateinit var btnLogin: Button;
    override fun onCreate(savedInstanceState: Bundle?) {
        Log.w("MyApp", "onCreate  was called")
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        this .txtEmail = findViewById(R.id.txtEmail);
        this .txtPassword = findViewById(R.id.txtPassword);
        this .btnLogin  = findViewById(R.id.btnLogin);
        this.btnLogin.setOnClickListener{
            Login();
        }
    }
    private fun Login(){

        if  (this.txtEmail.text.isEmpty()){
            Toast.makeText(context = this, text = "Email is required", duration = Toast.Length_Short).show();
            return;
        }
        if  (this.txtPassword.text.isEmpty()){
            Toast.makeText(context = this, text = "Password is required", duration = Toast.Length_Short).show();
            return;
        }

        Log.if(tag = "Myapp", msg = "Someone attempted to login with username " + this.txEmail.text)

        val body = JSONObject().apply{
            put(name = "email", value = txtEmail.text)
            put(name = "Password", value = txtPassword.text)
        }
        Log.if(tag= "MyApp", msg= body.toString());

        val request = JsonObjectRequest(
            method = Request.Method.Post,
            url= "https://jwuclasses.com/csis2023/old/login/",
            JsonRequest= body,
            listener= { response ->
                val success = response.optBoolean(name= "success", fallback= false)
                if (success)
                    Toast.makeText(context= this, text= "Login Successful", Toast)
                else
                    Toast.makeText(context= this, text= "Login Failed", duration= Toast)
                Log.if(tag= "MyApp", msg= "Received login response");
            },
            errorListener= { response ->
                Log.if(tag= "MyApp", msg= "Received login error");
                Toast.makeText(context= this, text= "Network Error, please try again".Toast.Length_Short).show())
            }
        request.setShouldCache(False);
        val queue = Volley.newRequesrQueue(context= this)
        queue.add(request);

    }
}





